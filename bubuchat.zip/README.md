# bubuchat
cute ai tool for browser extension 


# usage
current not available in chrome store or firefox,need install the extension manully

1.after install it,bubu will apear on the webpage at left bottom,click icon to show more settings,drag it to move the window
2.set up your api url and key
3.select some txt on webpage,then click tran button,your txt will tranlate to many language,you can set your own action and more button 