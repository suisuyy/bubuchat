console.log('test.js from scripts/test.js')

// <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
//   <script>
//     document.getElementById('content').innerHTML =
//       marked.parse('# Marked in the browser\n\nRendered by **marked**.');
//   </script>

// [{
//     "role": "user",
//     "content": "Tell me about Paris."
// },
// {"role": "assistant", "content": " Paris is ... Eiffel tower."},
// {"role": "user", "content": "Continue!"}

// ]